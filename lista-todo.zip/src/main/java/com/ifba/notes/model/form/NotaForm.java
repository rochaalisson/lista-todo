package com.ifba.notes.model.form;

import lombok.Getter;

@Getter
public class NotaForm {
	private String titulo;
	private String conteudo;
}
